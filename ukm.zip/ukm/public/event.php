<!DOCTYPE html>
<html lang="en-US" dir="ltr">
<?php
require 'koneksi.php';
$events = mysqli_query($conn, "SELECT * FROM tbl_kegiatan");
function konversiTanggal($tanggal)
{
  // Mengonversi tanggal ke dalam array dengan format [jam, tanggal, bulan]
  $jam = date("H:i", strtotime($tanggal)); // Mendapatkan jam dan menit dari tanggal
  $tanggal = date("j", strtotime($tanggal)); // Mendapatkan tanggal dari tanggal
  $bulan = date("M", strtotime($tanggal)); // Mendapatkan nama bulan dengan format tiga huruf

  $hasil = array($jam, $tanggal, $bulan);
  return $hasil;
}
function konversiTanggalFormat($tanggal)
{
  $tanggalKonversi = date("j F Y", strtotime($tanggal));
  return $tanggalKonversi;
}
?>

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css" rel="stylesheet" />

  <!-- title -->
  <title>UKM</title>

  <!--    Favicons-->
  <link rel="shortcut icon" type="image/x-icon" href="assets/img/logo.png" />
  <meta name="theme-color" content="#ffffff" />

  <!--    Stylesheets-->
  <link href="assets/css/theme.css" rel="stylesheet" />
  <style>
    .cut-text {
      text-overflow: ellipsis;
      height: 3em;
      white-space: nowrap;
      overflow: hidden;
    }

    .waktu {
      position: absolute;
      right: 24px;
      bottom: 16px;
    }
  </style>
</head>

<body>
  <!--    Main Content-->
  <main class="main" id="top">
    <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" style="background-color: #fff">
      <div class="container">
        <a class="navbar-brand d-flex align-items-center fw-semi-bold fs-3" href="index.html">
          <img class="me-3" src="assets/img/gallery/logohome.png" alt="" />
        </a>
        <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
          aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse border-top border-lg-0 mt-4 mt-lg-0" id="navbarSupportedContent">
          <ul class="navbar-nav mx-auto pt-2 pt-lg-0 font-base">
            <li class="nav-item px-2" data-anchor="data-anchor">
              <a class="nav-link fw-medium active" aria-current="page" href="index.html"></a>
            </li>
            <li class="nav-item px-2">
              <a class="nav-link" href="fullcalendar-6.1.9\examples\eventkalender.html"></a>
            </li>
            <li class="nav-item px-2">
              <a class="nav-link" href="aboutukm.html"></a>
            </li>
            <li class="nav-item px-2">
              <a class="nav-link" href="prestasi.html"></a>
            </li>
            <li class="nav-item px-2">
              <a class="nav-link" href="bagan.html"></a>
            </li>
          </ul>
          <form class="ps-lg-5">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"
              style="color: #3db166" />
          </form>
        </div>
      </div>
    </nav>

    <section class="py-0" id="home">
      <div class="bg-holder d-none d-md-block" style="
            background-image: url(assets/img/gallery/hero.png);
            background-position: right bottom;
            background-size: contain;
            margin-top: 5.625rem;
          "></div>
      <!--bg-holder-->

      <div class="bg-holder d-block d-md-none" style="
            background-image: url(assets/img/illustrations/hero-bg.png);
            background-position: right top;
            background-size: contain;
            margin-top: 5.625rem;
          "></div>
      <!--bg-holder-->
    </section>

    <!-- <section> begin ============================-->
    <section id="events">
      <div class="container">
        <div class="row">
          <div class="col-lg-7 mx-auto text-center mb-4">
            <h5 class="fw-light fs-3 fs-lg-5 lh-sm mb-3">
              Baca Tulisan Kami
            </h5>
            <p class="mb-3">
              Baca dan ikuti event serta program-program yang kami lakukan
              untuk fakultas teknik yang lebih baik!!!
            </p>
          </div>
        </div>
        <div class="row h-100 justify-content-center">
          <?php
          while ($event = mysqli_fetch_array($events)) {
            $waktu = konversiTanggal($event["kegiatan_tanggal"])
              ?>
            <div class="col-md-4 mb-4">
              <div class="card h-100 shadow px-2 px-lg-3 card-span pt-4 position-relative">
                <div class="text-center text-md-start card-hover">
                  <div class="card-body">
                    <div class="d-flex align-items-center">
                      <!-- <span class="badge bg-soft-primary text-primary fs-1 fw-light p-3 rounded-1">
                        
                      </span> -->
                      <img
                        src="https://plus.unsplash.com/premium_photo-1676490700212-5b1627ddacfd?q=80&w=1887&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                        alt="" style="width: 72px; height: 72px;" class="rounded-1" />
                      <div class="ms-3">
                        <h6 class="fw-light fs-1 fs-lg-2 text-start mb-0">
                          <?php echo $event['kegiatan_nama'] ?>
                        </h6>
                        <span style="font-size: 14px;">
                          <?= konversiTanggalFormat($event["kegiatan_tanggal"]) ?>
                        </span>
                      </div>

                    </div>
                    <p class="mt-4 mb-md-0 mb-lg-3 fw-light lh-base text-start">
                      <?php echo $event['kegiatan_deskripsi'] ?>
                    </p>
                    <div class="d-flex justify-content-end waktu">
                      <div class="d-flex align-items-center">
                        <svg class="bi bi-alarm me-2" xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                          fill="currentColor" viewBox="0 0 16 16">
                          <path
                            d="M8.5 5.5a.5.5 0 0 0-1 0v3.362l-1.429 2.38a.5.5 0 1 0 .858.515l1.5-2.5A.5.5 0 0 0 8.5 9V5.5z">
                          </path>
                          <path
                            d="M6.5 0a.5.5 0 0 0 0 1H7v1.07a7.001 7.001 0 0 0-3.273 12.474l-.602.602a.5.5 0 0 0 .707.708l.746-.746A6.97 6.97 0 0 0 8 16a6.97 6.97 0 0 0 3.422-.892l.746.746a.5.5 0 0 0 .707-.708l-.601-.602A7.001 7.001 0 0 0 9 2.07V1h.5a.5.5 0 0 0 0-1h-3zm1.038 3.018a6.093 6.093 0 0 1 .924 0 6 6 0 1 1-.924 0zM0 3.5c0 .753.333 1.429.86 1.887A8.035 8.035 0 0 1 4.387 1.86 2.5 2.5 0 0 0 0 3.5zM13.5 1c-.753 0-1.429.333-1.887.86a8.035 8.035 0 0 1 3.527 3.527A2.5 2.5 0 0 0 13.5 1z">
                          </path>
                        </svg>
                        <p class="mb-0 fw-light text-dark fs--1">
                          <?php echo $waktu[0] . " - Selesai" ?>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          <?php } ?>
        </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      <!-- end of .container-->
    </section>

    <!-- footer-->
    <section class="py-0 bg-primary">
      <div class="container">
        <div class="row justify-content-between pb-2 pt-8">
          <div class="col-12 col-lg-auto mb-5 mb-lg-0">
            <p class="my-3 text-100 fw-light">
              <b>Alamat </b> <br />
              Fakultas Teknik Universitas Riau Kampus Binawidya<br />
              Jl. HR Soebrantas KM. 12.5, <br />Simpang Baru, Binawidya
              Pekanbaru – 28293 <br />
              Email: informatika@eng.unri.ac.
            </p>
          </div>
          <div class="col-auto mb-3">
            <ul class="list-unstyled mb-md-4 mb-lg-0">
              <li class="mb-3">
                <a class="text-100 fw-light text-decoration-none" href="#!"><b>POST</b></a>
              </li>
              <li class="mb-3">
                <a class="text-100 fw-light text-decoration-none" href="#!">Berita</a>
              </li>
              <li class="mb-3">
                <a class="text-100 fw-light text-decoration-none" href="#!">Event</a>
              </li>
              <li class="mb-3">
                <a class="text-100 fw-light text-decoration-none" href="#!">Blog</a>
              </li>
            </ul>
          </div>
          <div class="col-auto mb-3">
            <ul class="list-unstyled mb-md-4 mb-lg-0">
              <li class="mb-3">
                <a class="text-100 fw-light text-decoration-none" href="#!"><b>PROGRAM</b></a>
              </li>
              <li class="mb-3">
                <a class="text-100 fw-light text-decoration-none" href="#!">UKMI</a>
              </li>
              <li class="mb-3">
                <a class="text-100 fw-light text-decoration-none" href="#!">TEKNO</a>
              </li>
              <li class="mb-3">
                <a class="text-100 fw-light text-decoration-none" href="#!">MAPALA</a>
              </li>
            </ul>
          </div>
          <div class="col-auto mb-4 d-flex align-items-end">
            <ul class="list-unstyled list-inline mb-0">
              <li class="list-inline-item me-3">
                <a class="text-decoration-none" href="#!">
                  <svg class="bi bi-facebook" xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#ffffff"
                    viewBox="0 0 16 16">
                    <path
                      d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z">
                    </path>
                  </svg>
                </a>
              </li>
              <li class="list-inline-item me-3">
                <a href="#!">
                  <svg class="bi bi-twitter" xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#ffffff"
                    viewBox="0 0 16 16">
                    <path
                      d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z">
                    </path>
                  </svg>
                </a>
              </li>
              <li class="list-inline-item me-3">
                <a href="#!">
                  <svg class="bi bi-instagram" xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#ffffff"
                    viewBox="0 0 16 16">
                    <path
                      d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z">
                    </path>
                  </svg>
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-auto mb-2">
            <p class="mb-0 fs--1 my-2 text-100">
              &copy; This template is made with&nbsp;
              <svg class="bi bi-suit-heart-fill" xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                fill="#2b2b2b" viewBox="0 0 16 16">
                <path
                  d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z">
                </path>
              </svg>
              &nbsp;by&nbsp;<a class="text-100" href="https://themewagon.com/" target="_blank">Kelompok 5
              </a>
            </p>
          </div>
        </div>
      </div>
      <!-- end footer-->
    </section>
  </main>

  <!--    JavaScripts-->
  <script src="vendors/@popperjs/popper.min.js"></script>
  <script src="vendors/bootstrap/bootstrap.min.js"></script>
  <script src="vendors/is/is.min.js"></script>
  <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
  <script src="assets/js/theme.js"></script>
  <script>
    // Memilih elemen-elemen yang diperlukan
    const cardContainers = document.querySelectorAll(".card-container");
    const prevPageButton = document.getElementById("prevPage");
    const nextPageButton = document.getElementById("nextPage");
    const pageNumber = document.getElementById("pageNumber");
    const totalPages = Math.ceil(cardContainers.length / 6); // Hitung jumlah total halaman
    let currentPage = 1;

    // Fungsi untuk menampilkan kartu sesuai halaman
    function showCards(page) {
      const startIndex = (page - 1) * 6;
      const endIndex = startIndex + 6;

      // Sembunyikan semua kartu
      cardContainers.forEach((cardContainer) => {
        cardContainer.style.display = "none";
      });

      // Tampilkan kartu sesuai halaman
      for (let i = startIndex; i < endIndex && i < cardContainers.length; i++) {
        cardContainers[i].style.display = "block";
      }
    }

    // Event listener untuk tombol "Prev"
    prevPageButton.addEventListener("click", function () {
      if (currentPage > 1) {
        currentPage--;
        updatePageNumber();
        showCards(currentPage);
      }
    });

    // Event listener untuk tombol "Next"
    nextPageButton.addEventListener("click", function () {
      if (currentPage < totalPages) {
        currentPage++;
        updatePageNumber();
        showCards(currentPage);
      }
    });

    // Fungsi untuk memperbarui nomor halaman
    function updatePageNumber() {
      pageNumber.textContent = currentPage;
    }

    // Inisialisasi
    showCards(currentPage);
    updatePageNumber();
  </script>


  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800;900&amp;display=swap"
    rel="stylesheet" />
</body>

</html>