<?php
require 'koneksii.php';
$id = $_GET["id"];

if (!empty($id)) {
    $query_sql = "DELETE FROM tbl_kegiatan WHERE kegiatan_id=$id";
} else {
    echo "Penghapusan Data Event Gagal : id tidak ditemukan";
}

if (mysqli_query($koneksii, $query_sql)) {
    header("Location:kegiatan.php");
} else {
    echo "Penghapusan Data Event Gagal : " . mysqli_error($koneksii);
}