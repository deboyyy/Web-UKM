<?php
require 'koneksii.php';
$nama = $_POST["nama"];
$tahun = $_POST["tahun"];
$deskripsi = $_POST["deskripsi"];

if (!empty($nama) && !empty($tahun) && !empty($deskripsi)) {
    $query_sql = "INSERT INTO tbl_prestasi (prestasi_nama, prestasi_tahun, prestasi_deskripsi)
              VALUES ('$nama', '$tahun', '$deskripsi')";
} else {
    echo "Error: ada kolom yang belum diisi";
}


if (mysqli_query($koneksii, $query_sql)) {
    header("Location:prestasi.php");
} else {
    echo "Penambahan Data Event Gagal : " . mysqli_error($koneksii);
}