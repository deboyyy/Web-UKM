<?php
require 'koneksii.php';
$nama = $_POST["nama"];
$type = $_POST["type"];
$deskripsi = $_POST["deskripsi"];

if (!empty($nama) && !empty($type) && !empty($deskripsi)) {
    $query_sql = "INSERT INTO tbl_dokumen (dokumen_nama, dokumen_type, dokumen_deskripsi)
              VALUES ('$nama', '$type', '$deskripsi')";
} else {
    echo "Error: ada kolom yang belum diisi";
}


if (mysqli_query($koneksii, $query_sql)) {
    header("Location:dokumen.php");
} else {
    echo "Penambahan Data Event Gagal : " . mysqli_error($koneksii);
}