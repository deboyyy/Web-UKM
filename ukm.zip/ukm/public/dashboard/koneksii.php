<?php
$koneksii = mysqli_connect("localhost", "root", "", "db_users");

if (mysqli_connect_errno()) {
    echo "Koneksi Gagal:" . mysqli_connect_errno();
}
?>