<?php
require 'koneksii.php';
$id = $_POST["id"];
$nama = $_POST["nama"];
// $waktu = $_POST["waktu"];
$lokasi = $_POST['lokasi'];
$deskripsi = $_POST["deskripsi"];

if (!empty($nama) && !empty($lokasi) && !empty($deskripsi)) {
    $query_sql = "UPDATE tbl_kegiatan SET kegiatan_nama = '$nama', kegiatan_lokasi = '$lokasi', kegiatan_deskripsi='$deskripsi')
              WHERE kegiatan_id=$id";
} else {
    echo "Error: ada kolom yang belum diisi";
}


if (mysqli_query($koneksii, $query_sql)) {
    header("Location:kegiatan.php");
} else {
    echo "Penambahan Data Event Gagal : " . mysqli_error($koneksii);
}