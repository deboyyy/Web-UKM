<?php
require 'koneksi.php';
$fullname = $_POST["Fullname"];
$username = $_POST["Username"];
$jurusan = $_POST['Jurusan'];
$email = $_POST["Email"];
$password = $_POST["Password"];

$query_sql = "INSERT INTO tbl_users (fullname, username, jurusan, email, password)
              VALUES ('$fullname', '$username', '$jurusan', '$email', '$password')";


if (mysqli_query($conn, $query_sql)) {
    header("Location:loginregis.html");
} else {
    echo "Pendaftaran Gagal : " . mysqli_error($conn);
}